const express = require("express");
const routerSepatu = express.Router()
const controllerSepatu = require('../controllers/sepatu')

routerSepatu.route('/sepatu')
    .get(controllerSepatu.getSepatu)
    .post(controllerSepatu.insert)

routerSepatu.route('/sepatu/:merk')
    .put(controllerSepatu.update)
    .delete(controllerSepatu.delete)
    .get(controllerSepatu.getSepatuByMerk)

routerSepatu.route('/sepatu/produk/:merk')
    .get(controllerSepatu.getProdukByMerk)
    .put(controllerSepatu.insertProduk)

module.exports = routerSepatu