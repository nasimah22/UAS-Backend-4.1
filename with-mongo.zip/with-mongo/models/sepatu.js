const mongoose = require('mongoose')

const sptSchema = new mongoose.Schema({
    merk : {
        require : true,
        type : String
    },
    ukuran : String,
    warna : String,
    harga : String,
})

module.exports = mongoose.model('Sepatu', sptSchema,'sepatu')