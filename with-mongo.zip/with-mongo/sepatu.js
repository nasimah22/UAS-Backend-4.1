const express = require("express");
const routerSepatu = express.Router()

let sepatu = [{merk:'vans', ukuran:'37', warna:'hitam', harga:'150',create:new Date()},
                 {merk:'converse', ukuran:'38', warna:'putih', harga:'200',create:new Date()},
                 {merk:'fila', ukuran:'39', warna:'merah', harga:'100',create:new Date()},
                ]

const cari = (arrData,merk) =>{
    ketemu = -1
    indeks = 0
    while(ketemu == -1 && indeks < arrData.length){
        if(arrData[indeks].merk == merk){
            ketemu = indeks
            return indeks
        }
        indeks++
    }
    return -1
}

routerSepatu.route('/sepatu')
    .get( (req,res)=>{
        res.json(sepatu)
    })

    .post((req,res)=>{
        //Ambil data request dari front end
        const newItem = {
            merk : req.body.merk,
            ukuran : req.body.ukuran,
            warna : req.body.warna,
            harga : req.body.harga
        }
        sepatu.push(newItem)
        res.status(201).json(newItem)
    })

routerSepatu.route('/sepatu/:merk')
    .put((req,res)=>{
        merk = req.params.merk
        indeks = cari(sepatu,merk)
        if(indeks != -1){
            sepatu[indeks].merk = merk
            sepatu[indeks].ukuran = req.body.ukuran
            sepatu[indeks].warna = req.body.warna
            sepatu[indeks].harga = req.body.harga

            res.json(sepatu[indeks])
        }
        else{
            res.send('Data sepatu tidak ditemukan')
        }
        
    })

    .delete((req,res)=>{
        merk = req.params.merk
        indeks = cari(sepatu,merk)
        if(indeks != -1){
            sepatu.splice(indeks,1)
            res.send('Sepatu dengan Merk ' + merk + ' telah dihapus')
        }
        else
        {
            res.send('Data sepatu tidak ditemukan')
        }
        
    })

    .get((req,res)=>{
        merk = req.params.merk
        indeks = cari(sepatu,merk)
        if(indeks != -1){
            const dataSepatu = {merk:sepatu[indeks].merk,
                                   ukuran:sepatu[indeks].ukuran,
                                   warna:sepatu[indeks].warna,
                                   harga:sepatu[indeks].harga
                                  }
            res.json(dataSepatu)
        }
        else{
            res.send('Sepatu dengan merk : ' + merk + ' tidak ditemukan')
        }
        
    })

routerSepatu.get('/sepatu/:ukuran/:terlaris', (req,res)=>{
    const ukuran = req.params.ukuran
    const terlaris = req.params.terlaris
    res.send('Sepatu ukuran : ' + ukuran + ' terlaris : ' + terlaris)
})

module.exports = routerSepatu